<!DOCTYPE html>
<html>
<head><title>Welcome</title></head>
<body><h1>Laravel Welcome Page</h1></body>
</html>